package com.demotest.Demo.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


/**
 * The persistent class for the hi_medicaid_member_ins_plan database table.
 * 
 */
@Entity(name = "IntakeEpicured.HiMemberReferral")
@Table(name = "hi_member_referral")

public class HiMemberReferral implements Serializable {
	
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="hi_member_referral_id")
	private Integer hiMemberReferralId = null;
	
	@Column(name="hi_medicaid_member_ins_plan_id")
	private Integer hiMedicaidMemberInsPlanId;
	
	@Column(name="hi_member_profile_id")
	private Integer hiMemberProfileId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="start_date")
	private Date startDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="end_date")
	private Date endDate;

	@Column(name="referral_status")
	private String referralStatus;

	@Column(name="medicaid_id")
	private String medicaidId;

	@Column(name="pregnant_member_service")
	private String pregnantMemberService;
	
	@Column(name="is_eligible")
	private String isEligible;
	
	@Column(name="allowed_orders")
	private Integer allowedOrders;
	
	@Column(name="remaining_orders")
	private Integer remainingOrders;

	@Column(name="allowed_meals")
	private Integer allowedMeals;

	@Column(name="remaining_meals")
	private Integer remainingMeals;
	
	@Column(name="required_gaps_betn_orders")
	private String requiredGapsBetnOrders;
	
	@Column(name="subscription_allowed")
	private String subscriptionAllowed;
	
	@Column(name="subscription_order_frequency")
	private String subscriptionOrderFrequency;

	@Column(name="is_copay_allowed")
	private String isCopayAllowed;

	@Column(name="max_copay_order")
	private Integer maxCopayOrder;
	
	@Column(name="member_copay_amount")
	private Float memberCopayAmount;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="modified_by")
	private String modifiedBy;
	
	@Column(name="created_datetime")
	private Timestamp createdDatetime;
	
	@Column(name="modified_datetime")
	private Timestamp modifiedDatetime;
	
	@Column(name="eligibility_file_name")
	private String eligibilityFileName;
	
	@Column(name="eligibility_file_path")
	private String eligibilityFilePath;
	
	@Column(name="total_eligible_weeks")
	private Integer totalEligibleWeeks;
	
	@Column(name="remaining_weeks")
	private Integer remainingWeeks;
	
	@Column(name="order_week")
	private Integer orderWeek;
	
	@Column(name="auth_number")
	private String authNumber;
	
	@Column(name="referral_type")
	private String referralType;
	
	@Column(name="auth_file_name")
	private String authFileName;
	
	@Column(name="auth_file_path")
	private String authFilePath;
	
	@Temporal(TemporalType.DATE)
	@Column(name="auth_date")
	private Date authDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="effective_date")
	private Date effectiveDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="through_date")
	private Date throughDate;
	
	@Column(name="no_of_units_approved")
	private String noOfUnitsApproved;
	
	@Column(name="unit_type")
	private String unitType;
	
	@Temporal(TemporalType.DATE)
	@Column(name="eligibility_date")
	private Date eligibilityDate;
	
	@Temporal(TemporalType.DATE)
	@Column(name="eligibility_checked_date")
	private Date eligibilityCheckedDate;
	
	@Column(name="remaining_units")
	private String remainingUnits;
	
	@Column(name="is_eligibility_screen_uploaded")
	private boolean isEligibilityScreenUploaded;
	
	@Column(name="manual_eligibility")
	private boolean manualEligibility;
	
	@Column(name="intake_eligibility_file_name")
	private String intakeEligibilityFileName;
	
	@Column(name="intake_eligibility_file_path")
	private String intakeEligibilityFilePath;
	
	@Column(name="status")
	private String status;
	
	public HiMemberReferral() {
	}


	public Integer getHiMedicaidMemberInsPlanId() {
		return hiMedicaidMemberInsPlanId;
	}

	public void setHiMedicaidMemberInsPlanId(Integer hiMedicaidMemberInsPlanId) {
		this.hiMedicaidMemberInsPlanId = hiMedicaidMemberInsPlanId;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getAllowedOrders() {
		return allowedOrders;
	}

	public void setAllowedOrders(Integer allowedOrders) {
		this.allowedOrders = allowedOrders;
	}

	public Integer getRemainingOrders() {
		return remainingOrders;
	}

	public void setRemainingOrders(Integer remainingOrders) {
		this.remainingOrders = remainingOrders;
	}

	public Integer getAllowedMeals() {
		return allowedMeals;
	}

	public void setAllowedMeals(Integer allowedMeals) {
		this.allowedMeals = allowedMeals;
	}

	public Integer getRemainingMeals() {
		return remainingMeals;
	}

	public void setRemainingMeals(Integer remainingMeals) {
		this.remainingMeals = remainingMeals;
	}

	public String getRequiredGapsBetnOrders() {
		return requiredGapsBetnOrders;
	}

	public void setRequiredGapsBetnOrders(String requiredGapsBetnOrders) {
		this.requiredGapsBetnOrders = requiredGapsBetnOrders;
	}

	public String getSubscriptionAllowed() {
		return subscriptionAllowed;
	}

	public void setSubscriptionAllowed(String subscriptionAllowed) {
		this.subscriptionAllowed = subscriptionAllowed;
	}

	public String getSubscriptionOrderFrequency() {
		return subscriptionOrderFrequency;
	}

	public void setSubscriptionOrderFrequency(String subscriptionOrderFrequency) {
		this.subscriptionOrderFrequency = subscriptionOrderFrequency;
	}

	public String getIsCopayAllowed() {
		return isCopayAllowed;
	}

	public void setIsCopayAllowed(String isCopayAllowed) {
		this.isCopayAllowed = isCopayAllowed;
	}

	public Integer getMaxCopayOrder() {
		return maxCopayOrder;
	}

	public void setMaxCopayOrder(Integer maxCopayOrder) {
		this.maxCopayOrder = maxCopayOrder;
	}

	public Float getMemberCopayAmount() {
		return memberCopayAmount;
	}

	public void setMemberCopayAmount(Float memberCopayAmount) {
		this.memberCopayAmount = memberCopayAmount;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getCreatedDatetime() {
		return createdDatetime;
	}

	public void setCreatedDatetime(Timestamp createdDatetime) {
		this.createdDatetime = createdDatetime;
	}

	public Timestamp getModifiedDatetime() {
		return modifiedDatetime;
	}

	public void setModifiedDatetime(Timestamp modifiedDatetime) {
		this.modifiedDatetime = modifiedDatetime;
	}

	public Integer getTotalEligibleWeeks() {
		return totalEligibleWeeks;
	}

	public void setTotalEligibleWeeks(Integer totalEligibleWeeks) {
		this.totalEligibleWeeks = totalEligibleWeeks;
	}

	public Integer getRemainingWeeks() {
		return remainingWeeks;
	}

	public void setRemainingWeeks(Integer remainingWeeks) {
		this.remainingWeeks = remainingWeeks;
	}

	public Integer getOrderWeek() {
		return orderWeek;
	}

	public void setOrderWeek(Integer orderWeek) {
		this.orderWeek = orderWeek;
	}

	public String getReferralType() {
		return referralType;
	}

	public void setReferralType(String referralType) {
		this.referralType = referralType;
	}


	public Integer getHiMemberReferralId() {
		return hiMemberReferralId;
	}


	public void setHiMemberReferralId(Integer hiMemberReferralId) {
		this.hiMemberReferralId = hiMemberReferralId;
	}


	public Integer getHiMemberProfileId() {
		return hiMemberProfileId;
	}


	public void setHiMemberProfileId(Integer hiMemberProfileId) {
		this.hiMemberProfileId = hiMemberProfileId;
	}


	public String getReferralStatus() {
		return referralStatus;
	}


	public void setReferralStatus(String referralStatus) {
		this.referralStatus = referralStatus;
	}


	public String getMedicaidId() {
		return medicaidId;
	}


	public void setMedicaidId(String medicaidId) {
		this.medicaidId = medicaidId;
	}


	public String getPregnantMemberService() {
		return pregnantMemberService;
	}


	public void setPregnantMemberService(String pregnantMemberService) {
		this.pregnantMemberService = pregnantMemberService;
	}


	public String getIsEligible() {
		return isEligible;
	}


	public void setIsEligible(String isEligible) {
		this.isEligible = isEligible;
	}


	public String getEligibilityFileName() {
		return eligibilityFileName;
	}


	public void setEligibilityFileName(String eligibilityFileName) {
		this.eligibilityFileName = eligibilityFileName;
	}


	public String getEligibilityFilePath() {
		return eligibilityFilePath;
	}


	public void setEligibilityFilePath(String eligibilityFilePath) {
		this.eligibilityFilePath = eligibilityFilePath;
	}


	public String getAuthNumber() {
		return authNumber;
	}


	public void setAuthNumber(String authNumber) {
		this.authNumber = authNumber;
	}


	public String getAuthFileName() {
		return authFileName;
	}


	public void setAuthFileName(String authFileName) {
		this.authFileName = authFileName;
	}


	public String getAuthFilePath() {
		return authFilePath;
	}


	public void setAuthFilePath(String authFilePath) {
		this.authFilePath = authFilePath;
	}


	public Date getAuthDate() {
		return authDate;
	}


	public void setAuthDate(Date authDate) {
		this.authDate = authDate;
	}


	public Date getEffectiveDate() {
		return effectiveDate;
	}


	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}


	public Date getThroughDate() {
		return throughDate;
	}


	public void setThroughDate(Date throughDate) {
		this.throughDate = throughDate;
	}


	public String getNoOfUnitsApproved() {
		return noOfUnitsApproved;
	}


	public void setNoOfUnitsApproved(String noOfUnitsApproved) {
		this.noOfUnitsApproved = noOfUnitsApproved;
	}


	public String getUnitType() {
		return unitType;
	}


	public void setUnitType(String unitType) {
		this.unitType = unitType;
	}


	public Date getEligibilityDate() {
		return eligibilityDate;
	}


	public void setEligibilityDate(Date eligibilityDate) {
		this.eligibilityDate = eligibilityDate;
	}


	public Date getEligibilityCheckedDate() {
		return eligibilityCheckedDate;
	}


	public void setEligibilityCheckedDate(Date eligibilityCheckedDate) {
		this.eligibilityCheckedDate = eligibilityCheckedDate;
	}


	public String getRemainingUnits() {
		return remainingUnits;
	}


	public void setRemainingUnits(String remainingUnits) {
		this.remainingUnits = remainingUnits;
	}


	public boolean isEligibilityScreenUploaded() {
		return isEligibilityScreenUploaded;
	}


	public void setEligibilityScreenUploaded(boolean isEligibilityScreenUploaded) {
		this.isEligibilityScreenUploaded = isEligibilityScreenUploaded;
	}


	public boolean isManualEligibility() {
		return manualEligibility;
	}


	public void setManualEligibility(boolean manualEligibility) {
		this.manualEligibility = manualEligibility;
	}


	public String getIntakeEligibilityFileName() {
		return intakeEligibilityFileName;
	}


	public void setIntakeEligibilityFileName(String intakeEligibilityFileName) {
		this.intakeEligibilityFileName = intakeEligibilityFileName;
	}


	public String getIntakeEligibilityFilePath() {
		return intakeEligibilityFilePath;
	}


	public void setIntakeEligibilityFilePath(String intakeEligibilityFilePath) {
		this.intakeEligibilityFilePath = intakeEligibilityFilePath;
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}
	
	
}