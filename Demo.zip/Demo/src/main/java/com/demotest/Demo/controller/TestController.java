package com.demotest.Demo.controller;

import java.util.List;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demotest.Demo.model.HiMemberOrder;
import com.demotest.Demo.request.OrderDetail;
import com.demotest.Demo.service.HiMemberOrderService;

import jakarta.servlet.http.HttpServletRequest;


@RestController
public class TestController {
	
	private static final Logger logger = LoggerFactory.getLogger(HiMemberOrderService.class);
	
	@Autowired
	private HiMemberOrderService hiMemberOrderService;
	
	@RequestMapping(value = "/memberOrder/{hiMemberProfileId}", method = RequestMethod.GET)
	public List<HiMemberOrder> getOrderList(@PathVariable("hiMemberProfileId") int hiMemberProfileId){
		try {
			List<HiMemberOrder> memberOrdersDetailList = hiMemberOrderService.getMemberOrdersDetailByhiMemberProfileId(hiMemberProfileId);
			System.out.println("memberOrdersDetailList"+memberOrdersDetailList);
			return memberOrdersDetailList;
		}catch(Exception e) {
			e.getMessage();
			e.printStackTrace();
		}
		return null;
	}
	
	@RequestMapping(value = "/memberOrderList/{hiMemberProfileId}", method = RequestMethod.GET)
	public ResponseEntity<OrderDetail> getMemberOrderDetails(HttpServletRequest httpRequest, @PathVariable("hiMemberProfileId") Integer hiMemberProfileId) {
		logger.info("MedicaidRestController::getMemberProfile::Start");
		logger.info("handleUpdateTracking::hiMemberProfileId={}",hiMemberProfileId);
		OrderDetail orderDetail = new OrderDetail();;
		try {
				if(hiMemberProfileId != null) {
					orderDetail = hiMemberOrderService.getMemberOrderDetails(hiMemberProfileId);
					if(orderDetail!=null) {
						orderDetail.setMessage("Success.....");
						return new ResponseEntity<>(orderDetail, HttpStatus.OK);
					}else  {
						orderDetail = new OrderDetail();
						logger.info("getMemberOrderDetails::File Id is null or empty={}",hiMemberProfileId);
						orderDetail.setMessage("Required parameter is missing or empty");
						return new ResponseEntity<>(orderDetail, HttpStatus.NOT_FOUND);
					}
				}
		} catch (Exception e) {
			logger.error("MedicaidRestController::getMemberProfile={}", e.getMessage());
			e.printStackTrace();
		}
		logger.info("MedicaidRestController::getMemberProfile::End");
		return new ResponseEntity<>(orderDetail, HttpStatus.BAD_REQUEST);
	}
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String sayHello() {
		return "Hello....!!";
	}

}
