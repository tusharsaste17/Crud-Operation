package com.demotest.Demo.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;


/**
 * The persistent class for the hi_member_order_detail database table.
 * 
 */
@Entity(name = "IntakeEpicured.HiMemberOrder")
@Table(name = "hi_member_order")
public class HiMemberOrder implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="hi_member_order_id")
	private Integer hiMemberOrderId = null;
	
	@Column(name="hi_member_profile_id")
	private Integer hiMemberProfileId;
	
	@Column(name="hi_bundle_mstr_id")
	private Integer hiBundleMstrId;
	
	@Column(name="order_number")
	private String orderNumber;
	
	@Column(name="bundle_name")
	private String bundleName;
	
	@Column(name="order_quantity")
	private Integer orderQuantity;
	
	@Column(name="bundle_sku")
	private String bundleSku;
	
	@Column(name="individual_skus")
	private String individualSkus;
	
	@Column(name="created_by")
	private String createdBy;

	@Column(name="created_datetime")
	private Timestamp createdDatetime;

	@Column(name="order_datetime")
	private Timestamp orderDatetime;

	private String status;

	@Column(name="modified_by")
	private String modifiedBy;

	@Column(name="modified_datetime")
	private Timestamp modifiedDatetime;

	@Column(name="notes")
	private String notes;
	
	@Column(name="hi_medicaid_member_ins_plan_id")
	private Integer hiMedicaidMemberInsPlanId;
	
	@Column(name="hi_ins_benefit_mstr_id")
	private Integer hiInsBenefitMstrId;

	@Column(name="contact_name")
	private String contactName;
	
	@Column(name="phone_number")
	private String phoneNumber;
	
	@Column(name="total_orders")
	private Integer totalOrders;
	
	@Column(name="remaining_orders")
	private Integer remainingOrders;
	
	@Column(name="is_subcription_allowed")
	private boolean isSubcriptionAllowed;
	
	@Column(name="hi_member_subscription_id")
	private Integer hiMemberSubscriptionId;

	@Temporal(TemporalType.DATE)
	@Column(name="order_processing_date")
	private Date orderProcessingDate;
	
	@Column(name="week")
	private String week;
	
	@Column(name="hi_member_referral_id")
	private Integer hiMemberReferralId;
	
	@Column(name="referral_type")
	private String referralType;
	
	@Column(name="units")
	private Integer units;
	
	@Column(name="rpa_billing_status")
	private String rpaBillingStatus;
	
	@Column(name="billing_date")
	private Timestamp billingDate;
	
	@Column(name="billing_screen_name")
	private String billingScreenName;
	
	@Column(name="billing_screen_path")
	private String billingScreenPath;
	
	@Column(name="delivery_failed")
	private String deliveryFailed;
	
	@Column(name="delivery_failed_reason")
	private String deliveryFailedReason;
	
	
	public HiMemberOrder() {
	}

	public Integer getHiMemberOrderId() {
		return hiMemberOrderId;
	}

	public void setHiMemberOrderId(Integer hiMemberOrderId) {
		this.hiMemberOrderId = hiMemberOrderId;
	}

	public Integer getHiMemberProfileId() {
		return hiMemberProfileId;
	}

	public void setHiMemberProfileId(Integer hiMemberProfileId) {
		this.hiMemberProfileId = hiMemberProfileId;
	}

	public Integer getHiBundleMstrId() {
		return hiBundleMstrId;
	}

	public void setHiBundleMstrId(Integer hiBundleMstrId) {
		this.hiBundleMstrId = hiBundleMstrId;
	}

	public String getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(String orderNumber) {
		this.orderNumber = orderNumber;
	}

	public String getBundleName() {
		return bundleName;
	}

	public void setBundleName(String bundleName) {
		this.bundleName = bundleName;
	}

	public Integer getOrderQuantity() {
		return orderQuantity;
	}

	public void setOrderQuantity(Integer orderQuantity) {
		this.orderQuantity = orderQuantity;
	}

	public String getBundleSku() {
		return bundleSku;
	}

	public void setBundleSku(String bundleSku) {
		this.bundleSku = bundleSku;
	}

	public String getIndividualSkus() {
		return individualSkus;
	}

	public void setIndividualSkus(String individualSkus) {
		this.individualSkus = individualSkus;
	}


	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Timestamp getCreatedDatetime() {
		return createdDatetime;
	}

	public void setCreatedDatetime(Timestamp createdDatetime) {
		this.createdDatetime = createdDatetime;
	}

	public Timestamp getOrderDatetime() {
		return orderDatetime;
	}

	public void setOrderDatetime(Timestamp orderDatetime) {
		this.orderDatetime = orderDatetime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Timestamp getModifiedDatetime() {
		return modifiedDatetime;
	}

	public void setModifiedDatetime(Timestamp modifiedDatetime) {
		this.modifiedDatetime = modifiedDatetime;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public Integer getHiMedicaidMemberInsPlanId() {
		return hiMedicaidMemberInsPlanId;
	}

	public void setHiMedicaidMemberInsPlanId(Integer hiMedicaidMemberInsPlanId) {
		this.hiMedicaidMemberInsPlanId = hiMedicaidMemberInsPlanId;
	}

	public Integer getHiInsBenefitMstrId() {
		return hiInsBenefitMstrId;
	}

	public void setHiInsBenefitMstrId(Integer hiInsBenefitMstrId) {
		this.hiInsBenefitMstrId = hiInsBenefitMstrId;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Integer getTotalOrders() {
		return totalOrders;
	}

	public void setTotalOrders(Integer totalOrders) {
		this.totalOrders = totalOrders;
	}

	public Integer getRemainingOrders() {
		return remainingOrders;
	}

	public void setRemainingOrders(Integer remainingOrders) {
		this.remainingOrders = remainingOrders;
	}

	public boolean isSubcriptionAllowed() {
		return isSubcriptionAllowed;
	}

	public void setSubcriptionAllowed(boolean isSubcriptionAllowed) {
		this.isSubcriptionAllowed = isSubcriptionAllowed;
	}

	public Integer getHiMemberSubscriptionId() {
		return hiMemberSubscriptionId;
	}

	public void setHiMemberSubscriptionId(Integer hiMemberSubscriptionId) {
		this.hiMemberSubscriptionId = hiMemberSubscriptionId;
	}

	public Date getOrderProcessingDate() {
		return orderProcessingDate;
	}

	public void setOrderProcessingDate(Date orderProcessingDate) {
		this.orderProcessingDate = orderProcessingDate;
	}

	public String getWeek() {
		return week;
	}

	public void setWeek(String week) {
		this.week = week;
	}

	public Integer getHiMemberReferralId() {
		return hiMemberReferralId;
	}

	public void setHiMemberReferralId(Integer hiMemberReferralId) {
		this.hiMemberReferralId = hiMemberReferralId;
	}

	public String getReferralType() {
		return referralType;
	}

	public void setReferralType(String referralType) {
		this.referralType = referralType;
	}

	public Integer getUnits() {
		return units;
	}

	public void setUnits(Integer units) {
		this.units = units;
	}

	public String getRpaBillingStatus() {
		return rpaBillingStatus;
	}

	public void setRpaBillingStatus(String rpaBillingStatus) {
		this.rpaBillingStatus = rpaBillingStatus;
	}

	public Timestamp getBillingDate() {
		return billingDate;
	}

	public void setBillingDate(Timestamp billingDate) {
		this.billingDate = billingDate;
	}

	public String getBillingScreenName() {
		return billingScreenName;
	}

	public void setBillingScreenName(String billingScreenName) {
		this.billingScreenName = billingScreenName;
	}

	public String getBillingScreenPath() {
		return billingScreenPath;
	}

	public void setBillingScreenPath(String billingScreenPath) {
		this.billingScreenPath = billingScreenPath;
	}

	public String getDeliveryFailed() {
		return deliveryFailed;
	}

	public void setDeliveryFailed(String deliveryFailed) {
		this.deliveryFailed = deliveryFailed;
	}

	public String getDeliveryFailedReason() {
		return deliveryFailedReason;
	}

	public void setDeliveryFailedReason(String deliveryFailedReason) {
		this.deliveryFailedReason = deliveryFailedReason;
	}
}