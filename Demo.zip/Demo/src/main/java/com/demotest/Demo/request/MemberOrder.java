package com.demotest.Demo.request;

import java.io.Serializable;

public class MemberOrder implements Serializable {

	private int hiMemberOrderId;
	private int hiMemberProfileId;
	private int hiMemberReferralId;
	private String status;
	private String week;
	private String referralType;
	
	public int getHiMemberOrderId() {
		return hiMemberOrderId;
	}
	public void setHiMemberOrderId(int hiMemberOrderId) {
		this.hiMemberOrderId = hiMemberOrderId;
	}
	public int getHiMemberProfileId() {
		return hiMemberProfileId;
	}
	public void setHiMemberProfileId(int hiMemberProfileId) {
		this.hiMemberProfileId = hiMemberProfileId;
	}
	public int getHiMemberReferralId() {
		return hiMemberReferralId;
	}
	public void setHiMemberReferralId(int hiMemberReferralId) {
		this.hiMemberReferralId = hiMemberReferralId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getWeek() {
		return week;
	}
	public void setWeek(String week) {
		this.week = week;
	}
	public String getReferralType() {
		return referralType;
	}
	public void setReferralType(String referralType) {
		this.referralType = referralType;
	}
	@Override
	public String toString() {
		return "MemberOrder [hiMemberOrderId=" + hiMemberOrderId + ", hiMemberProfileId=" + hiMemberProfileId
				+ ", status=" + status + ", week=" + week + ", referralType=" + referralType + "]";
	}
}