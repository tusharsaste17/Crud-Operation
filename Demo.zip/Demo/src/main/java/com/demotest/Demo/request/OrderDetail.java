package com.demotest.Demo.request;

import java.io.Serializable;
import java.util.List;

public class OrderDetail implements Serializable {

	private List<MemberOrder> memberOrderList;
	private String message;
	
	public List<MemberOrder> getMemberOrderList() {
		return memberOrderList;
	}
	public void setMemberOrderList(List<MemberOrder> memberOrderList) {
		this.memberOrderList = memberOrderList;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	@Override
	public String toString() {
		return "OrderDetail [memberOrderList=" + memberOrderList + ", message=" + message + "]";
	}

}
