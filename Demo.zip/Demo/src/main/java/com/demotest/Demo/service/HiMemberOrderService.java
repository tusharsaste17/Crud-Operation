package com.demotest.Demo.service;


import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demotest.Demo.model.HiMemberOrder;
import com.demotest.Demo.model.HiMemberReferral;
import com.demotest.Demo.repo.HiMemberOrderRepository;
import com.demotest.Demo.repo.HiMemberReferralRepository;
import com.demotest.Demo.request.MemberOrder;
import com.demotest.Demo.request.OrderDetail;

@Service
public class HiMemberOrderService {
	
	private static final Logger logger = LoggerFactory.getLogger(HiMemberOrderService.class);
	
	@Autowired
	private HiMemberOrderRepository hiMemberOrderRepository;
	@Autowired
	private HiMemberReferralRepository hiMemberReferralRepository;
	

	public List<HiMemberOrder> getMemberOrdersDetailByhiMemberProfileId(int hiMemberProfileId) {
		try {
				/*for single member at a time */
			//triggerGetMemberOrderDetailRequest(hiMemberProfileId);
				/* for multiple members at one time */
			for (int i = 200; i > 0; i--) {
				logger.debug("getMemberOrderUpdate::hiMemberProfileId={}", hiMemberProfileId);
				triggerGetMemberOrderDetailRequest(hiMemberProfileId);
				hiMemberProfileId = hiMemberProfileId +1;
			}
			
			return hiMemberOrderRepository.findByHiMemberProfileId(hiMemberProfileId);
		}catch(Exception e) {
			System.err.println(e.getMessage());
			e.printStackTrace();
		}
		return null;
	}
	
	 public void triggerGetMemberOrderDetailRequest(Integer hiMemberProfileId) {
		 logger.info("triggerGetMemberOrderDetailRequest::Start");
		  try {
			  HttpResponse response = null;
			  String getRestURL =  "http://localhost:8090/memberOrderList/"+hiMemberProfileId;
			  //logger.debug("emRestWelcomeURL={} ", getRestURL);
			  HttpClient httpClient = HttpClientBuilder.create().build();
			  HttpGet getRequest = new HttpGet(getRestURL);

			  response = httpClient.execute(getRequest);
			  String result = EntityUtils.toString(response.getEntity());
			  logger.debug("triggerMemberNotification::result={}",result);
			  test(result);
			}  catch (Exception e) {
				logger.error("triggerGetMemberOrderDetailRequest::Exception occured={}",e.getMessage());
				e.printStackTrace();
			}
			logger.info("triggerGetMemberOrderDetailRequest::End");
		}
	 
		public void test(String jsonInput) throws Exception {
			//System.out.println("test::START");
			
			ObjectMapper mapper = new ObjectMapper();

			Map<String, Object> root = mapper.readValue(jsonInput, new TypeReference<Map<String, Object>>() {
			});
			List<Map<String, Object>> orders = (List<Map<String, Object>>) root.get("memberOrderList");

			Map<String, List<Map<String, Object>>> grouped = orders.stream().filter(o -> o.get("referralType") != null)
					.collect(Collectors.groupingBy(o -> o.get("referralType").toString()));

			for (Map.Entry<String, List<Map<String, Object>>> entry : grouped.entrySet()) {
				List<Map<String, Object>> groupOrders = entry.getValue();
				for (int i = 0; i < groupOrders.size(); i++) {
					groupOrders.get(i).put("week", String.valueOf(i + 1));
				}
			}

			for (Map<String, Object> order : orders) {
				Integer hiMemberOrderId = (Integer)order.get("hiMemberOrderId");
				Integer hiMemberProfileId = (Integer)order.get("hiMemberProfileId");
				String week = (String)order.get("week");
				Integer hiMemberReferralId = (Integer)order.get("hiMemberReferralId");
				String referralType = (String)order.get("referralType");
//				System.out.println("hiMemberOrderId={}"+hiMemberOrderId);
//				System.out.println("hiMemberProfileId={}"+hiMemberProfileId);
//				System.out.println("week={}"+week);
//				System.out.println("hiMemberReferralId={}"+hiMemberReferralId);
//				System.out.println("referralType={}"+referralType);
				
				HiMemberReferral memberReferralByType = hiMemberReferralRepository.getMemberReferralByType(hiMemberProfileId, referralType);
				Integer totalEligibleWeeks = memberReferralByType.getTotalEligibleWeeks();
				Integer orerWeeks = Integer.parseInt(week);
				
				Integer remainingWeeks = totalEligibleWeeks - orerWeeks;
				//System.out.println("remainingWeeks = "+remainingWeeks);
				System.out.println("UPDATE hi_member_referral SET order_week ="+orerWeeks+", remaining_weeks= "+remainingWeeks+"  WHERE hi_member_referral_id ="+hiMemberReferralId+";");
				//System.out.println("UPDATE hi_member_order SET week ="+week+" WHERE hi_member_order_id ="+hiMemberOrderId+";");
			
				//hiMemberOrderRepository.updateOrderWeek(week, hiMemberOrderId);
				//hiMemberReferralRepository.updateOrderWeekCount(orerWeeks,remainingWeeks,hiMemberReferralId);
				if (order.get("referralType") == null) {
					order.put("week", null);
				}
			}
			String updatedJson = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(root);
			//System.out.println("updatedJson={} "+ updatedJson);
			}
		public OrderDetail getMemberOrderDetails(Integer hiMemberProfileId) {
			logger.info("getMemberOrderDetails::Start");
			OrderDetail orderDetail = null;
			try {	
				if(hiMemberProfileId != null) {
					List<HiMemberOrder> memberOrderList = hiMemberOrderRepository.findByHiMemberProfileId(hiMemberProfileId);
					orderDetail = new OrderDetail();
					List<MemberOrder> resopnseMemberOrderList = new ArrayList<MemberOrder>();
					for(HiMemberOrder hiMemberOrder : memberOrderList) {
						MemberOrder memberOrder = new MemberOrder();
						memberOrder.setHiMemberOrderId(hiMemberOrder.getHiMemberOrderId());
						memberOrder.setHiMemberProfileId(hiMemberOrder.getHiMemberProfileId());
						memberOrder.setStatus(hiMemberOrder.getStatus());
						memberOrder.setWeek(hiMemberOrder.getWeek());
						memberOrder.setHiMemberReferralId(hiMemberOrder.getHiMemberReferralId());
						memberOrder.setReferralType(hiMemberOrder.getReferralType());
						resopnseMemberOrderList.add(memberOrder);
						orderDetail.setMemberOrderList(resopnseMemberOrderList);
					}
				}
			} catch (Exception e) {
				logger.error("An error getMemberOrderDetails occured {}", e);
				e.printStackTrace();
			}
			logger.debug("getMemberOrderDetails::End");
			return orderDetail;
		}
}
